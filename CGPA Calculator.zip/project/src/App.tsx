import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Calculator, BookOpen, Award } from 'lucide-react';

interface Subject {
  id: string;
  name: string;
  credits: number;
  cie: number;
  see: number;
  grade: number;
  points: number;
}

interface Semester {
  id: string;
  name: string;
  subjects: Subject[];
  sgpa: number;
}

const gradeScale = [
  { min: 90, grade: 'O', points: 10 },
  { min: 80, grade: 'A+', points: 9 },
  { min: 70, grade: 'A', points: 8 },
  { min: 60, grade: 'B+', points: 7 },
  { min: 50, grade: 'B', points: 6 },
  { min: 40, grade: 'PASS', points: 5 },
  { min: 0, grade: 'F', points: 0 }
];

function App() {
  const [semesters, setSemesters] = useState<Semester[]>([
    {
      id: '1',
      name: 'Semester 1',
      subjects: [],
      sgpa: 0
    }
  ]);
  const [activeSemester, setActiveSemester] = useState('1');

  const getGradeFromMarks = (marks: number) => {
    const grade = gradeScale.find(g => marks >= g.min);
    return grade || { grade: 'F', points: 0 };
  };

  const calculateSGPA = (subjects: Subject[]) => {
    if (subjects.length === 0) return 0;
    
    const totalCredits = subjects.reduce((sum, subject) => sum + subject.credits, 0);
    const totalPoints = subjects.reduce((sum, subject) => sum + (subject.credits * subject.points), 0);
    
    return totalCredits > 0 ? totalPoints / totalCredits : 0;
  };

  const calculateCGPA = () => {
    let totalCredits = 0;
    let totalPoints = 0;
    
    semesters.forEach(semester => {
      semester.subjects.forEach(subject => {
        totalCredits += subject.credits;
        totalPoints += subject.credits * subject.points;
      });
    });
    
    return totalCredits > 0 ? totalPoints / totalCredits : 0;
  };

  const addSubject = (semesterId: string) => {
    setSemesters(prev => 
      prev.map(semester => 
        semester.id === semesterId 
          ? {
              ...semester,
              subjects: [...semester.subjects, {
                id: Date.now().toString(),
                name: '',
                credits: 1,
                cie: 0,
                see: 0,
                grade: 0,
                points: 0
              }]
            }
          : semester
      )
    );
  };

  const removeSubject = (semesterId: string, subjectId: string) => {
    setSemesters(prev => 
      prev.map(semester => 
        semester.id === semesterId 
          ? {
              ...semester,
              subjects: semester.subjects.filter(s => s.id !== subjectId)
            }
          : semester
      )
    );
  };

  const updateSubject = (semesterId: string, subjectId: string, field: string, value: any) => {
    setSemesters(prev => 
      prev.map(semester => 
        semester.id === semesterId 
          ? {
              ...semester,
              subjects: semester.subjects.map(subject => {
                if (subject.id === subjectId) {
                  const updated = { ...subject, [field]: value };
                  if (field === 'cie' || field === 'see') {
                    const totalMarks = (field === 'cie' ? value : updated.cie) + (field === 'see' ? value : updated.see);
                    const gradeInfo = getGradeFromMarks(totalMarks);
                    updated.grade = totalMarks;
                    updated.points = gradeInfo.points;
                  }
                  return updated;
                }
                return subject;
              })
            }
          : semester
      )
    );
  };

  const addSemester = () => {
    const newId = (semesters.length + 1).toString();
    setSemesters(prev => [...prev, {
      id: newId,
      name: `Semester ${semesters.length + 1}`,
      subjects: [],
      sgpa: 0
    }]);
  };

  useEffect(() => {
    setSemesters(prev => 
      prev.map(semester => ({
        ...semester,
        sgpa: calculateSGPA(semester.subjects)
      }))
    );
  }, [semesters]);

  const currentSemester = semesters.find(s => s.id === activeSemester);
  const cgpa = calculateCGPA();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <BookOpen className="h-12 w-12 text-indigo-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-800">CGPA Calculator</h1>
          </div>
          <p className="text-gray-600">Calculate your SGPA and CGPA with grade predictions</p>
        </div>

        {/* CGPA Display */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-indigo-500">
            <div className="flex items-center">
              <Award className="h-8 w-8 text-indigo-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-gray-600">Current CGPA</p>
                <p className="text-3xl font-bold text-indigo-600">{cgpa.toFixed(3)}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div className="flex items-center">
              <Calculator className="h-8 w-8 text-green-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-gray-600">Current SGPA</p>
                <p className="text-3xl font-bold text-green-600">
                  {currentSemester ? currentSemester.sgpa.toFixed(3) : '0.000'}
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
            <div className="flex items-center">
              <Calculator className="h-8 w-8 text-purple-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-gray-600">Total Subjects</p>
                <p className="text-3xl font-bold text-purple-600">
                  {semesters.reduce((sum, s) => sum + s.subjects.length, 0)}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Semester Tabs */}
        <div className="bg-white rounded-xl shadow-lg mb-8">
          <div className="flex flex-wrap border-b border-gray-200 p-4">
            {semesters.map(semester => (
              <button
                key={semester.id}
                onClick={() => setActiveSemester(semester.id)}
                className={`mr-4 mb-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeSemester === semester.id
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {semester.name}
                <span className="ml-2 text-sm opacity-75">
                  (SGPA: {semester.sgpa.toFixed(2)})
                </span>
              </button>
            ))}
            <button
              onClick={addSemester}
              className="px-4 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors flex items-center"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Semester
            </button>
          </div>

          {/* Subject Management */}
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-800">
                {currentSemester?.name} Subjects
              </h2>
              <button
                onClick={() => addSubject(activeSemester)}
                className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors flex items-center"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Subject
              </button>
            </div>

            {/* Subjects Table */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border border-gray-300 px-4 py-3 text-left">Subject</th>
                    <th className="border border-gray-300 px-4 py-3 text-center">Credits</th>
                    <th className="border border-gray-300 px-4 py-3 text-center">CIE</th>
                    <th className="border border-gray-300 px-4 py-3 text-center">SEE</th>
                    <th className="border border-gray-300 px-4 py-3 text-center">Total</th>
                    <th className="border border-gray-300 px-4 py-3 text-center">Grade</th>
                    <th className="border border-gray-300 px-4 py-3 text-center">Points</th>
                    <th className="border border-gray-300 px-4 py-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {currentSemester?.subjects.map(subject => {
                    const gradeInfo = getGradeFromMarks(subject.grade);
                    return (
                      <tr key={subject.id} className="hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-3">
                          <input
                            type="text"
                            value={subject.name}
                            onChange={(e) => updateSubject(activeSemester, subject.id, 'name', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            placeholder="Subject name"
                          />
                        </td>
                        <td className="border border-gray-300 px-4 py-3 text-center">
                          <input
                            type="number"
                            value={subject.credits}
                            onChange={(e) => updateSubject(activeSemester, subject.id, 'credits', parseInt(e.target.value))}
                            className="w-20 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 text-center"
                            min="1"
                            max="10"
                          />
                        </td>
                        <td className="border border-gray-300 px-4 py-3 text-center">
                          <input
                            type="number"
                            value={subject.cie}
                            onChange={(e) => updateSubject(activeSemester, subject.id, 'cie', parseInt(e.target.value))}
                            className="w-20 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 text-center"
                            min="0"
                            max="100"
                          />
                        </td>
                        <td className="border border-gray-300 px-4 py-3 text-center">
                          <input
                            type="number"
                            value={subject.see}
                            onChange={(e) => updateSubject(activeSemester, subject.id, 'see', parseInt(e.target.value))}
                            className="w-20 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 text-center"
                            min="0"
                            max="100"
                          />
                        </td>
                        <td className="border border-gray-300 px-4 py-3 text-center font-medium">
                          {subject.grade}
                        </td>
                        <td className="border border-gray-300 px-4 py-3 text-center">
                          <span className={`px-2 py-1 rounded-full text-sm font-medium ${
                            gradeInfo.grade === 'O' ? 'bg-green-100 text-green-800' :
                            gradeInfo.grade === 'A+' ? 'bg-blue-100 text-blue-800' :
                            gradeInfo.grade === 'A' ? 'bg-indigo-100 text-indigo-800' :
                            gradeInfo.grade === 'B+' ? 'bg-purple-100 text-purple-800' :
                            gradeInfo.grade === 'B' ? 'bg-yellow-100 text-yellow-800' :
                            gradeInfo.grade === 'PASS' ? 'bg-orange-100 text-orange-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {gradeInfo.grade}
                          </span>
                        </td>
                        <td className="border border-gray-300 px-4 py-3 text-center font-medium">
                          {subject.points}
                        </td>
                        <td className="border border-gray-300 px-4 py-3 text-center">
                          <button
                            onClick={() => removeSubject(activeSemester, subject.id)}
                            className="text-red-600 hover:text-red-800 transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {currentSemester?.subjects.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No subjects added yet. Click "Add Subject" to get started.
              </div>
            )}
          </div>
        </div>

        {/* Grading Scale Reference */}
        <div className="bg-white rounded-xl shadow-lg p-6 mt-8">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Grading Scale Reference</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {gradeScale.slice(0, -1).map(scale => (
              <div key={scale.grade} className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-lg font-bold text-gray-800">{scale.grade}</div>
                <div className="text-sm text-gray-600">{scale.min}+ marks</div>
                <div className="text-sm font-medium text-indigo-600">{scale.points} points</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;