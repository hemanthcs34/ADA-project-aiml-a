# CGPA Calculator

A comprehensive web-based CGPA (Cumulative Grade Point Average) calculator built with React, TypeScript, and Tailwind CSS. This application helps students calculate their SGPA (Semester Grade Point Average) and overall CGPA based on their academic performance.

## Features

### Core Functionality
- **Multi-semester Management**: Add and manage multiple semesters with individual SGPA tracking
- **Subject Management**: Add/remove subjects with customizable credits
- **Automatic Grade Calculation**: Real-time grade computation based on CIE + SEE scores
- **CGPA Calculation**: Overall CGPA calculation across all semesters
- **Responsive Design**: Works seamlessly on desktop and mobile devices

### User Interface
- **Modern Design**: Clean, professional interface with gradient backgrounds
- **Tabbed Interface**: Easy navigation between different semesters
- **Color-coded Grades**: Visual grade representation with color-coded badges
- **Real-time Updates**: Instant calculations as you input data
- **Grading Scale Reference**: Built-in reference for grade boundaries

## Algorithm & Calculation Method

### Grading Scale
The application uses the following grading scale based on total marks (CIE + SEE):

| Marks Range | Grade | Points |
|-------------|-------|--------|
| 90+         | O     | 10     |
| 80-89       | A+    | 9      |
| 70-79       | A     | 8      |
| 60-69       | B+    | 7      |
| 50-59       | B     | 6      |
| 40-49       | PASS  | 5      |
| Below 40    | F     | 0      |

### SGPA Calculation Algorithm

**Formula**: `SGPA = Σ(Credits × Grade Points) / Σ(Credits)`

**Steps**:
1. For each subject, calculate total marks: `Total = CIE + SEE`
2. Determine grade points based on total marks using the grading scale
3. Calculate weighted points: `Subject Points = Credits × Grade Points`
4. Sum all weighted points across subjects
5. Sum all credits across subjects
6. Divide total weighted points by total credits

**Example**:
```
Subject: ADA, Credits: 3, Marks: 85 → Grade: A+ (9 points)
Weighted Points = 3 × 9 = 27

Subject: AI, Credits: 4, Marks: 75 → Grade: A (8 points)
Weighted Points = 4 × 8 = 32

SGPA = (27 + 32) / (3 + 4) = 59 / 7 = 8.43
```

### CGPA Calculation Algorithm

**Formula**: `CGPA = Σ(All Credits × Grade Points) / Σ(All Credits)`

**Steps**:
1. Collect all subjects from all semesters
2. Calculate weighted points for each subject: `Credits × Grade Points`
3. Sum all weighted points across all semesters
4. Sum all credits across all semesters
5. Divide total weighted points by total credits

### Data Structure

```typescript
interface Subject {
  id: string;
  name: string;
  credits: number;
  cie: number;        // Continuous Internal Evaluation
  see: number;        // Semester End Examination
  grade: number;      // Total marks (CIE + SEE)
  points: number;     // Grade points based on grading scale
}

interface Semester {
  id: string;
  name: string;
  subjects: Subject[];
  sgpa: number;
}
```

## Technology Stack

- **Frontend Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS for responsive design
- **Icons**: Lucide React for modern iconography
- **Build Tool**: Vite for fast development and building
- **State Management**: React useState and useEffect hooks

## Getting Started

### Prerequisites
- Node.js (version 16 or higher)
- npm or yarn package manager

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd cgpa-calculator
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5173`

### Building for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## Usage Guide

### Adding Subjects
1. Select a semester tab or create a new semester
2. Click "Add Subject" button
3. Fill in subject details:
   - Subject name
   - Credits (1-10)
   - CIE marks (0-100)
   - SEE marks (0-100)

### Viewing Results
- **SGPA**: Displayed for each semester in the tab headers
- **CGPA**: Shown in the main dashboard
- **Grades**: Automatically calculated and color-coded in the table

### Managing Semesters
- Click "Add Semester" to create new semesters
- Switch between semesters using the tab interface
- Each semester maintains its own subject list and SGPA

## Code Architecture

### Component Structure
- **App.tsx**: Main component containing all logic and UI
- **Modular Functions**: Separate functions for calculations
- **Type Safety**: Full TypeScript implementation with interfaces

### Key Functions
- `getGradeFromMarks()`: Converts total marks to grade and points
- `calculateSGPA()`: Computes SGPA for a semester
- `calculateCGPA()`: Computes overall CGPA
- `updateSubject()`: Handles subject data updates with automatic recalculation

### State Management
- Uses React's built-in state management with useState
- Real-time updates with useEffect for automatic recalculations
- Immutable state updates for predictable behavior

## Performance Optimizations

- **Efficient Calculations**: Calculations only run when necessary
- **Optimized Re-renders**: Strategic use of useEffect dependencies
- **Responsive Design**: CSS Grid and Flexbox for optimal layouts
- **Fast Build**: Vite for lightning-fast development and builds

## Browser Compatibility

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Commit your changes: `git commit -am 'Add feature'`
4. Push to the branch: `git push origin feature-name`
5. Submit a pull request

## License

This project is open source and available under the [MIT License](LICENSE).

## Support

For support, questions, or feature requests, please open an issue in the repository.

---

**Note**: This calculator follows standard academic grading systems and may need adjustment based on specific institutional requirements.